<?php
$conexion=new mysqli("localhost","root","","basededatos_reservas");
$conexion->set_charset("utf8");
?>