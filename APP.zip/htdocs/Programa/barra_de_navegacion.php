<nav class="navbar navbar-expand-lg bg-primary">
  <div class="container-fluid">
    <b><a style="color:white; font-size: 18px;" class="nav-link" href="../Inicio de sesión/inicio.php">Inicio</a></b>  
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a style="color:white; font-size: 18px; font-weight: lighter;" class="nav-link" href="../Clientes/clientes.php">Clientes</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a style="color:white; font-size: 18px; font-weight: lighter;" class="nav-link navbar-brand" href="../Inicio de sesión/lista_de_usuarios.php">Lista de usuarios</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
        <form action="../Inicio de sesión/cerrar_sesion.php" method="POST">
        <button type="submit" name="cerrar_sesion" class="btn btn-danger">Cerrar sesión</button>
      </form>
        <button class="navbar-toggler ml-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
  </div>
</nav>