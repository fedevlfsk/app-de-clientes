<?php
include "../Programa/seguridad.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <!-- CSS -->
    <link href="../css/bootstrap.css" rel="stylesheet">
</head>
<body>
<?php
include "../Programa/barra_de_navegacion.php";
?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<h1 class="text-center text-secondary">Bienvenido a tu gestor de clientes</h1>
<br>
<h5 class="text-center text-secondary">usa la barra de navegación para empezar</h5>
</body>
</html>